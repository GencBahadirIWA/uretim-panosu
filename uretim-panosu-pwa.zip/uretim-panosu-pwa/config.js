// Google Cloud'da oluşturduğunuz OAuth istemci kimliği (…apps.googleusercontent.com)
window.UP_CONFIG = {
  CLIENT_ID: "BURAYA_ISTEMCI_KIMLIGI",
  // Drive'daki ortak klasör (masaüstü uygulaması ve test panosu da aynısını kullanır)
  FOLDER_ID: "1EHaODSNKfTyhMri60AREVYfa2fVDKtBr"
};
